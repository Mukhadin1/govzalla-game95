
const allQuestions = {
  "Знание чеченского языка": [
    { question: "Как будет 'мама' на чеченском языке?", options: ["Нана", "Даьда", "Шунна"], answer: "Нана" }
  ],
  "Традиции": [
    { question: "Как называется чеченская традиция гостеприимства?", options: ["Къонахалла", "Дешниса", "Дикам"], answer: "Къонахалла" }
  ],
  "Национальные герои": [
    { question: "Кто был известным чеченским полководцем в борьбе с царизмом?", options: ["Имам Шамиль", "Зелимхан", "Байсангур"], answer: "Зелимхан" }
  ],
  "Чеченские писатели": [
    { question: "Кто написал 'Песни Чечни'?", options: ["А. Айдамиров", "М. Лермонтов", "Ю. Керимов"], answer: "А. Айдамиров" }
  ]
};

let selectedCategory = "";
let currentIndex = 0;
let currentQuestions = [];

function startGame() {
  const select = document.getElementById('categorySelect');
  selectedCategory = select.value;
  if (!selectedCategory) return alert("Выберите категорию!");
  currentQuestions = allQuestions[selectedCategory];
  currentIndex = 0;
  showQuestion();
}

function showQuestion() {
  const container = document.getElementById('gameContainer');
  const q = currentQuestions[currentIndex];
  if (!q) {
    container.innerHTML = "<h2>Вы завершили опрос!</h2>";
    return;
  }

  container.innerHTML = `
    <div class="question-block">
      <h2>${q.question}</h2>
      ${q.options.map(opt => `<button onclick="checkAnswer('${opt}')">${opt}</button>`).join("<br/>")}
      <div id="feedback"></div>
    </div>
  `;
  setTimeout(() => {
    const feedback = document.getElementById("feedback");
    if (feedback) feedback.innerHTML = "<small>Время истекло. Переход к следующему вопросу.</small>";
    setTimeout(() => {
      currentIndex++;
      showQuestion();
    }, 2000);
  }, 10000);
}

function checkAnswer(selected) {
  const correct = allQuestions[selectedCategory][currentIndex].answer;
  const feedback = document.getElementById("feedback");
  if (selected === correct) {
    feedback.innerHTML = "<strong style='color: lightgreen;'>Верно!</strong>";
  } else {
    feedback.innerHTML = "<strong style='color: red;'>Неверно. Правильный ответ: " + correct + "</strong>";
  }
  setTimeout(() => {
    currentIndex++;
    showQuestion();
  }, 2000);
}

// Populate select options
window.onload = () => {
  const select = document.getElementById('categorySelect');
  Object.keys(allQuestions).forEach(cat => {
    const option = document.createElement("option");
    option.value = cat;
    option.textContent = cat;
    select.appendChild(option);
  });
};
